/*
 * defines.h
 */

#ifndef __DEFINES_H
#define __DEFINES_H

#define FCLOCK   84000000l


#endif
