#include "stm32f407xx.h"


int main()
	
{
	int j=0;
	RCC->APB1ENR |= (1<<29); // activer DAC
	
	RCC->AHB1ENR |= (1<<0);  // activer GPIO A
	
	GPIOA->MODER |= (3<<2*4)+(3<<2*5); // GPIO A PIn 4 et 5 analog
	
	DAC->CR |= (1<<0)+ (1<<16);
	
	while(1)
	{
		
  DAC->DHR12R1 = j&0xfff;
		DAC->DHR12R2 = 0xfff - (j&0xfff);
		j=(j+1)&0xfff;
	}
	
	
}
