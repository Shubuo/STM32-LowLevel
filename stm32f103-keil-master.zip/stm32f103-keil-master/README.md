# stm32f103-keil

Click here <a href="https://www.udemy.com/hands-on-stm32-basic-peripherals-with-hal/?couponCode=LEARNSTM32NOW">here</a> for STM32 tutorial using HAL library.
