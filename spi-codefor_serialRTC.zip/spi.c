/*******************************************************************************/
/*									       */
/*	Title: SPI Code							       */
/*									       */
/*	This example demo code is provided as is and has no warranty, implied  */
/*	or otherwise.  You are free to use/modify any of the provided code at  */
/*	your own risk in your applications.				       */
/*									       */
/*	LIMITATION OF LIABILITY:  NEITHER STMicroelectronics NOR ITS VENDORS   */
/*	OR AGENTS SHALL BE LIABLE FOR ANY LOSS OF PROFITS, LOST OF USE, LOSS   */
/*	OF DATA, INTERRUPTION OF BUSINESS, NOR FOR INDIRECT, SPECIAL,	       */
/*	INCIDENTAL OR CONSEQUENTIAL DAMAGES OF ANY KIND WHETHER UNDER THIS     */
/*	AGREEMENT OR OTHERWISE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH     */
/* 	DAMAGES.							       */
/*				                                               */
/*									       */
/*   	Application Test Program for: 					       */
/*	-----------------------------					       */	
/*									       */
/* 	      M41T94 (SPI - 20 Bytes RTC Reg. Map)     			       */	
/* 	      M41ST95 (SPI - 20 Bytes RTC Reg. Map)    			       */
/* 	      M41ST97 (SPI - RTC Reg. Map)	       			       */	
/*				 					       */
/*=============================================================================*/
/*									       */
/*	Rev.  Description		  Date:	       			       */
/*=============================================================================*/
/*									       */
/*	01 -  Initial Rev.		  03-01-03     			       */			
/*	      								       */
/*									       */	
/*******************************************************************************/
								
#include <c:\c51\inc\REG515.H> 		/* DEFINE 8051 REGISTERS */
#include <c:\c51\inc\STDIO.H> 		/* DEFINE I/O FUNCTIONS */
#include <c:\c51\inc\CTYPE.H>  		/* DEFINITIONS FOR CHAR CONVERSION */
#include <c:\c51\inc\ABSACC.H> 		/* DIRECT ACCESS TO 8051 MEMORY */
#include <c:\c51\inc\STDLIB.H> 		/* STANDARD LIBRARY */
#include <c:\c51\inc\STRING.H> 		/* STRING FUNCTIONS */
#include <c:\c51\inc\INTRINS.H> 


/********************** PORT ASSIGNMENTS **************************************/
/*									      */
/*  Use Port 1, 4 and 5 for the following signals.			      */
/*									      */
/*  P4.0 = SDA/SDO (Input/Output)					      */
/*  P4.1 = SCL	   (Input)						      */
/*  P4.2 = SDI     (Input)						      */
/*  P4.3 = /CE	   (Input)						      */	
/******************************************************************************/



/*********************** FUNCTIONS PROTOTYPE **********************************/
/*									      */
/******************************************************************************/

void main (void);
void Board_Init(void);

/*  SPI Functions Prototype */
void SPI_Mode0_Init();
void SPI_Mode3_Init();
void SPI_Write(unsigned char input_byte);
unsigned char SPI_Read();
void SPI_Write3(unsigned char input_byte);
unsigned char SPI_Read3();


/********************* DEFINE CONSTANTS & GLOBAL VARIABLES ********************/
/*									      */
/*   Define Timekeeper registers constants.				      */
/*									      */
/******************************************************************************/

#define Good_Device 1
#define Bad_Device 2

sbit SDA = P4^0;
sbit SCL = P4^1; 
sbit SDI = P4^2;
sbit CE =  P4^3;


/******************************************************************************/
/*	Subroutine:	Main			      		      	      */
/*			                                 		      */	
/*	Description:	Write and read to the Timekeeper Register and also    */
/*			write and read to the RAM.			      */
/*                                                                    	      */
/******************************************************************************/

void main(void)
{       /* Start of Main Program */
	unsigned char Bus_Sel, Dev_Sel;
	unsigned char Word_Add, RAM_Size;
	unsigned char Sel_RTC_Reg, RTC_Data;
	unsigned char Sec_Reg, Min_Reg, Hr_Reg, DOW_Reg, DOM_Reg, Mon_Reg, Yr_Reg;
	unsigned char Cont_Reg, Tenths_Sec_Reg, Wdog_Reg, Al_Mon_Reg, Al_DOM_Reg; 
	unsigned char Al_Hr_Reg, Al_Min_Reg, Al_Sec_Reg,  Flags_Reg, SQW_Reg;
	unsigned char Tamper1_Reg, Tamper2_Reg, Interrupts;
	unsigned char Sec_Data, Min_Data, Hr_Data, DOW_Data, DOM_Data, Mon_Data, Yr_Data;
	unsigned char j, i,  Number_Bytes, Error_Flag, Start_Add;
	unsigned char RAM_Data_In, RAM_Add, RAM_Data_Out, Dev_Add, RTC_Reg_Size, RAM_Density;
	


/******************************************************************************/
/*									      */
/*   Selection between I2C and SPI bus.					      */
/*									      */
/*	1 - SPI Bus (Mode 0)						      */
/*	2 - SPI Bus (Mode 3)						      */	
/*									      */
/******************************************************************************/

        Board_Init();
        Dev_Add = 0xD0;
	Bus_Sel = _getkey();
	switch (Bus_Sel)
	{                        /* Start of Bus Selection */


/******************************************************************************/
/*							 		      */
/*  		   SPI BUS PROTOCOL - Mode 0		       	 	      */
/*							   		      */
/******************************************************************************/

	   case 1: /* SPI Bus - Default to Mode 0 */
   		   {             /* Start of SPI Mode 0 */
    		   SPI_Mode0_Init();
   		   Dev_Sel = _getkey();                                       
   		   switch (Dev_Sel) 
 		        {        /* Start of Device Selection */
           		case 2 : /* M41T94/ST95 RAM Size */	
				 P5 = 0xD3;
		    		 RAM_Size = _getkey();
				 Word_Add = _getkey();
                    		 break ;

           		case 3 : /* M41ST97 RAM Size */
				 P5 = 0xC0;
		    		 RAM_Size = _getkey();
				 Word_Add = _getkey();
                    		 break ;
                                 
           		default:
 	       			 break ;                         
		        }        /* End of Device Selection */
		 
		   while(1)
		   {             /* Start of Input Selection */
	   		Sel_RTC_Reg = _getkey ();
                                                            
	   		switch (Sel_RTC_Reg)
	   		{	 /* Start of RTC Reg. Selection */
              		    case 11: /* write to seconds register */
		            	     RTC_Data = _getkey();
				     SPI_Mode0_Init();
				     SPI_Write(0x81);
	                             SPI_Write(RTC_Data);
				     SPI_Mode0_Init();
        	       		     break;
                                        	
              		    case 12: /* write to minutes register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x82);	
                                     SPI_Write(RTC_Data);
				     SPI_Mode0_Init();	
        	       		     break;

              		    case 13: /* write to hours register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x83);	
                                     SPI_Write(RTC_Data); 
				     SPI_Mode0_Init();
        	       		     break;

              		    case 14: /* write to day register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x84);
                                     SPI_Write(RTC_Data); 
				     SPI_Mode0_Init();
        	       		     break;

              		    case 15: /* write to date register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();	
				     SPI_Write(0x85);
	                             SPI_Write(RTC_Data); 
				     SPI_Mode0_Init();
        	       		     break;

              		    case 16: /* write to month register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x86);
                                     SPI_Write(RTC_Data);   
				     SPI_Mode0_Init();
        	      		     break;

              		    case 17: /* write to year register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x87);	
                                     SPI_Write(RTC_Data);   
				     SPI_Mode0_Init();
        	       		     break;

              		    case 18: /* write to control register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x88);	
                                     SPI_Write(RTC_Data);  
				     SPI_Mode0_Init();
        	       		     break;

              		    case 19: /* write to watchdog register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x89);	
                                     SPI_Write(RTC_Data);     
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 20: /* write to alarm month register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
				     SPI_Write(0x8A);	
                                     SPI_Write(RTC_Data); 
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 21: /* write to alarm date register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x8B);	
                                     SPI_Write(RTC_Data);   
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 22: /* write to alarm hour register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x8C);	
                                     SPI_Write(RTC_Data);    
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 23: /* write to alarm minute register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x8D);	
                                     SPI_Write(RTC_Data);    
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 24: /* write to alarm second register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();	
				     SPI_Write(0x8E);	
                                     SPI_Write(RTC_Data);   
	                             SPI_Mode0_Init(); 
        	       		     break;

              		    case 25: /* write OF bit to the flags register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x8F);	
                                     SPI_Write(RTC_Data);    
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 26: /* read the flags register */
		       		     SPI_Mode0_Init();
				     SPI_Write(0x0F);		
                                     Flags_Reg = SPI_Read();
		       		     putchar (Flags_Reg);
		       		     SPI_Mode0_Init();
        	       		     break;


/******************************************************************************/
/*									      */
/*   case 27-29 are not used (reserved registers)			      */
/*									      */
/******************************************************************************/


              		    case 30: /* write to SQW register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x93);	
                                     SPI_Write(RTC_Data);  
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 31: /* write to Tamper1 register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x94);	
                                     SPI_Write(RTC_Data); 
	                             SPI_Mode0_Init();
        	       		     break;

              		    case 32: /* write to Tamper2 register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode0_Init();
	                             SPI_Write(0x95);	
                                     SPI_Write(RTC_Data);
	                             SPI_Mode0_Init();
        	       		     break;


/******************************************************************************/
/*							 		      */
/*  	case 41 - Reading RTC Reg. of T94/ST95 devices (SPI).  		      */	
/*							   		      */
/******************************************************************************/

              		    case 41:
				     SPI_Mode0_Init();
           	 	             SPI_Write(0x00);        
		       		     Tenths_Sec_Reg = SPI_Read();	
		       		     Sec_Reg = SPI_Read();
		       		     Min_Reg = SPI_Read();
		       		     Hr_Reg =  SPI_Read();
		       		     DOW_Reg = SPI_Read();
                       		     DOM_Reg = SPI_Read();
		       		     Mon_Reg = SPI_Read();
		       		     Yr_Reg =  SPI_Read();
		       		     Cont_Reg = SPI_Read();
		        	     Wdog_Reg = SPI_Read();	
		       		     Al_Mon_Reg = SPI_Read();
		       		     Al_DOM_Reg = SPI_Read();
		       		     Al_Hr_Reg = SPI_Read();
		       		     Al_Min_Reg = SPI_Read();
		       		     Al_Sec_Reg = SPI_Read();	
                       		     SPI_Mode0_Init();

				     SPI_Write(0x13);                                               
		       		     SQW_Reg = SPI_Read();
		       		     SPI_Mode0_Init();

		       		     Interrupts = P1;

		       	 	     putchar (Tenths_Sec_Reg);
 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Wdog_Reg);
		       		     putchar (Al_Mon_Reg);
		      		     putchar (Al_DOM_Reg);
		       		     putchar (Al_Hr_Reg);
		       		     putchar (Al_Min_Reg);
		       		     putchar (Al_Sec_Reg);	
		       		     putchar (SQW_Reg);
		       		     putchar (Interrupts);	
        	      		     break;


/******************************************************************************/
/*							 		      */
/*  	case 42 - Reading RTC Reg. of ST97 device (SPI).  		      */	
/*							   		      */
/******************************************************************************/

              		    case 42: /* Read the RTC Reg. Map */
				     SPI_Mode0_Init();
           	 	             SPI_Write(0x00);        
		       		     Tenths_Sec_Reg = SPI_Read();	
		       		     Sec_Reg = SPI_Read();
		       		     Min_Reg = SPI_Read();
		       		     Hr_Reg =  SPI_Read();
		       		     DOW_Reg = SPI_Read();
                       		     DOM_Reg = SPI_Read();
		       		     Mon_Reg = SPI_Read();
		       		     Yr_Reg =  SPI_Read();
		       		     Cont_Reg = SPI_Read();
		        	     Wdog_Reg = SPI_Read();	
		       		     Al_Mon_Reg = SPI_Read();
		       		     Al_DOM_Reg = SPI_Read();
		       		     Al_Hr_Reg = SPI_Read();
		       		     Al_Min_Reg = SPI_Read();
		       		     Al_Sec_Reg = SPI_Read();	
                       		     SPI_Mode0_Init();

				     SPI_Write(0x13);                                               
		       		     SQW_Reg = SPI_Read();                                             
		       		     Tamper1_Reg = SPI_Read();
				     Tamper2_Reg = SPI_Read();
		       		     SPI_Mode0_Init();

		       		     Interrupts = P1;

		       	 	     putchar (Tenths_Sec_Reg);
 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Wdog_Reg);
		       		     putchar (Al_Mon_Reg);
		      		     putchar (Al_DOM_Reg);
		       		     putchar (Al_Hr_Reg);
		       		     putchar (Al_Min_Reg);
		       		     putchar (Al_Sec_Reg);	
		       		     putchar (SQW_Reg);
		       		     putchar (Tamper1_Reg);
		       		     putchar (Tamper2_Reg);
		       		     putchar (Interrupts);	
        	      		     break;


/*******************************************************************************/
/*							 		       */
/*  	case 45 - Write (Burst) Time to RTC Reg. 			       */	
/*		  					 		       */
/*******************************************************************************/

              		    case 45: 
		       		     Sec_Data = _getkey();
				     Min_Data = _getkey();
		       		     Hr_Data =  _getkey();
				     DOW_Data = _getkey();
		       		     DOM_Data = _getkey();
				     Mon_Data = _getkey();	
		       		     Yr_Data =  _getkey();

		       		     SPI_Mode0_Init();                   		 
                                     SPI_Write(0x81); 
				     SPI_Write(Sec_Data);
				     SPI_Write(Min_Data);
				     SPI_Write(Hr_Data);
				     SPI_Write(DOW_Data);
				     SPI_Write(DOM_Data);
				     SPI_Write(Mon_Data);
				     SPI_Write(Yr_Data);
		       		     SPI_Mode0_Init();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 50 - Write all zeroes & all ones to the RAM. 		      */
/*	case 51 - Write data to certain location of the RAM.		      */
/*							   		      */
/******************************************************************************/

	      		    case 50: /* write all zeroes or ones pattern to the RAM */	
		       		     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
				     Start_Add = Word_Add | 0x80; 
		       		     SPI_Mode0_Init();                  		 
                                     SPI_Write(Start_Add);                   		 

                       		     for (j=0; j<RAM_Density; j++)
		       		     {
        		  		 SPI_Write(RAM_Data_In);
                       		     }
		       		     SPI_Mode0_Init();
                       		     break;


	      		    case 51: /* write data to certain location of the RAM */
				     RAM_Add = _getkey();
		       		     Number_Bytes = _getkey();
		       		     RAM_Data_In = _getkey();
                                     RAM_Add = RAM_Add | 0x80;
		       		     SPI_Mode0_Init();  
                 		     SPI_Write(RAM_Add);                   		 

                       		     for (j=0; j<Number_Bytes+1; j++)
		       		     {
        		  		SPI_Write(RAM_Data_In);
                       		     }
				     SPI_Mode0_Init();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 55 - Read all zeroes and all ones from the RAM. 		      */
/*	case 56 - Read entire data from the RAM.			      */
/*							   		      */
/******************************************************************************/

              		    case 55: /* read all zeroes or all ones from the RAM */
			 	     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
		       		     Error_Flag = 0x00;
				     Start_Add = Word_Add;  
				     SPI_Mode0_Init();                    		 
                                     SPI_Write(Start_Add);        	 		
        
		       		     for (i=0; i < RAM_Density; i++)
		       		     {
		    	   		RAM_Data_Out = SPI_Read();
					if (RAM_Data_Out != RAM_Data_In)
		       	   		{
			      		    Error_Flag = 0x01;
		    	   		}
				     }           
                                     SPI_Mode0_Init();

		       		     if (Error_Flag == 0x01)
	    	          		putchar (Bad_Device);
	               		     else
	    	          		putchar (Good_Device);

        	       		     break;


              		    case 56: /* read entire data from the RAM */
				     SPI_Mode0_Init();           
                                     SPI_Write(0x00);

		       		     for (i=0; i<RAM_Size; i++)
		       		     {
		    	   		RAM_Data_Out = SPI_Read();
		    	   		putchar(RAM_Data_Out);
		       		     }
                                     SPI_Mode0_Init();
        	       		     break;

  	      		    default:
		       		     break;
	   		}        /* End of SPI Mode 0 Reg. Selection */
 	           }             /* End of Input Selection */
                   }             /* End of SPI Mode - case 2 */


/******************************************************************************/
/*							 		      */
/*  		   SPI BUS PROTOCOL - Mode 3		       	 	      */
/*							   		      */
/******************************************************************************/

	   case 2: /* SPI Bus  */
   		   {             /* Start of SPI Mode 3 */
    		   SPI_Mode3_Init();
   		   Dev_Sel = _getkey();                                       
   		   switch (Dev_Sel) 
 		        {        /* Start of Device Selection */
           		case 2 : /* M41T94/ST95 RAM Size */
				 P5 = 0xD3;	
		    		 RAM_Size = _getkey();
				 Word_Add = _getkey();
                    		 break ;

           		case 3 : /* M41ST97 RAM Size */
				 P5 = 0xC0;
		    		 RAM_Size = _getkey();
				 Word_Add = _getkey();
                    		 break ;
                                 
           		default:
 	       			 break ;                         
		        }        /* End of Device Selection */
		 
		   while(1)
		   {             /* Start of Input Selection */
	   		Sel_RTC_Reg = _getkey ();
                                                            
	   		switch (Sel_RTC_Reg)
	   		{	 /* Start of RTC Reg. Selection */
              		    case 11: /* write to seconds register */
		            	     RTC_Data = _getkey();
				     SPI_Mode3_Init();
				     SPI_Write3(0x81);
	                             SPI_Write3(RTC_Data);
				     SPI_Mode3_Init();
        	       		     break;
                                        	
              		    case 12: /* write to minutes register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x82);	
                                     SPI_Write3(RTC_Data);
				     SPI_Mode3_Init();	
        	       		     break;

              		    case 13: /* write to hours register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x83);	
                                     SPI_Write3(RTC_Data); 
				     SPI_Mode3_Init();
        	       		     break;

              		    case 14: /* write to day register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x84);
                                     SPI_Write3(RTC_Data); 
				     SPI_Mode3_Init();
        	       		     break;

              		    case 15: /* write to date register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();	
				     SPI_Write3(0x85);
	                             SPI_Write3(RTC_Data); 
				     SPI_Mode3_Init();
        	       		     break;

              		    case 16: /* write to month register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x86);
                                     SPI_Write3(RTC_Data);   
				     SPI_Mode3_Init();
        	      		     break;

              		    case 17: /* write to year register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x87);	
                                     SPI_Write3(RTC_Data);   
				     SPI_Mode3_Init();
        	       		     break;

              		    case 18: /* write to control register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x88);	
                                     SPI_Write3(RTC_Data);  
				     SPI_Mode3_Init();
        	       		     break;

              		    case 19: /* write to watchdog register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x89);	
                                     SPI_Write3(RTC_Data);     
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 20: /* write to alarm month register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
				     SPI_Write3(0x8A);	
                                     SPI_Write3(RTC_Data); 
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 21: /* write to alarm date register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x8B);	
                                     SPI_Write3(RTC_Data);   
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 22: /* write to alarm hour register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x8C);	
                                     SPI_Write3(RTC_Data);    
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 23: /* write to alarm minute register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x8D);	
                                     SPI_Write3(RTC_Data);    
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 24: /* write to alarm second register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();	
				     SPI_Write3(0x8E);	
                                     SPI_Write3(RTC_Data);   
	                             SPI_Mode3_Init(); 
        	       		     break;

              		    case 25: /* write OF bit to the flags register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x8F);	
                                     SPI_Write3(RTC_Data);    
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 26: /* read the flags register */
		       		     SPI_Mode3_Init();
				     SPI_Write3(0x0F);		
                                     Flags_Reg = SPI_Read3();
		       		     putchar (Flags_Reg);
		       		     SPI_Mode3_Init();
        	       		     break;


/******************************************************************************/
/*									      */
/*   case 27-29 are not used (reserved registers)			      */
/*									      */
/******************************************************************************/


              		    case 30: /* write to SQW register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x93);	
                                     SPI_Write3(RTC_Data);  
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 31: /* write to Tamper1 register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x94);	
                                     SPI_Write3(RTC_Data); 
	                             SPI_Mode3_Init();
        	       		     break;

              		    case 32: /* write to Tamper2 register */
		       		     RTC_Data = _getkey();	
				     SPI_Mode3_Init();
	                             SPI_Write3(0x95);	
                                     SPI_Write3(RTC_Data);
	                             SPI_Mode3_Init();
        	       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 41 - Reading the RTC Reg. of T94/ST95/ST97 devices (SPI)	      */	
/*							   		      */
/******************************************************************************/

              		    case 41:
				     SPI_Mode3_Init();
           	 	             SPI_Write3(0x00);        
		       		     Tenths_Sec_Reg = SPI_Read3();	
		       		     Sec_Reg = SPI_Read3();
		       		     Min_Reg = SPI_Read3();
		       		     Hr_Reg =  SPI_Read3();
		       		     DOW_Reg = SPI_Read3();
                       		     DOM_Reg = SPI_Read3();
		       		     Mon_Reg = SPI_Read3();
		       		     Yr_Reg =  SPI_Read3();
		       		     Cont_Reg = SPI_Read3();
		        	     Wdog_Reg = SPI_Read3();	
		       		     Al_Mon_Reg = SPI_Read3();
		       		     Al_DOM_Reg = SPI_Read3();
		       		     Al_Hr_Reg = SPI_Read3();
		       		     Al_Min_Reg = SPI_Read3();
		       		     Al_Sec_Reg = SPI_Read3();	
                       		     SPI_Mode3_Init();

				     SPI_Write3(0x13);                                               
		       		     SQW_Reg = SPI_Read3();
		       		     SPI_Mode3_Init();

		       		     Interrupts = P1;

		       	 	     putchar (Tenths_Sec_Reg);
 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Wdog_Reg);
		       		     putchar (Al_Mon_Reg);
		      		     putchar (Al_DOM_Reg);
		       		     putchar (Al_Hr_Reg);
		       		     putchar (Al_Min_Reg);
		       		     putchar (Al_Sec_Reg);
				     putchar (SQW_Reg);	
		       		     putchar (Interrupts);	
        	      		     break;

/*******************************************************************************/
/*							 		       */
/*  	case 45 - Write (Burst) Time to RTC Reg. 			       */	
/*		  					 		       */
/*******************************************************************************/

              		    case 45: 
		       		     Sec_Data = _getkey();
				     Min_Data = _getkey();
		       		     Hr_Data =  _getkey();
				     DOW_Data = _getkey();
		       		     DOM_Data = _getkey();
				     Mon_Data = _getkey();	
		       		     Yr_Data =  _getkey();

		       		     SPI_Mode3_Init();                   		 
                                     SPI_Write3(0x81); 
				     SPI_Write3(Sec_Data);
				     SPI_Write3(Min_Data);
				     SPI_Write3(Hr_Data);
				     SPI_Write3(DOW_Data);
				     SPI_Write3(DOM_Data);
				     SPI_Write3(Mon_Data);
				     SPI_Write3(Yr_Data);
		       		     SPI_Mode3_Init();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 50 - Write all zeroes & all ones to the RAM. 		      */
/*	case 51 - Write data to certain location of the RAM.		      */
/*							   		      */
/******************************************************************************/

	      		    case 50: /* write all zeroes or ones pattern to the RAM */	
		       		     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
				     Start_Add = Word_Add | 0x80;  
		       		     SPI_Mode3_Init();                   		 
                                     SPI_Write3(Start_Add);                   		 

                       		     for (j=0; j<RAM_Density; j++)
		       		     {
        		  		 SPI_Write3(RAM_Data_In);
                       		     }
		       		     SPI_Mode3_Init();
                       		     break;

	      		    case 51: /* write data to certain location of the RAM */
				     RAM_Add = _getkey();
		       		     Number_Bytes = _getkey();
		       		     RAM_Data_In = _getkey();
                                     RAM_Add = RAM_Add | 0x80;
		       		     SPI_Mode3_Init();  
                 		     SPI_Write3(RAM_Add);                   		 

                       		     for (j=0; j<Number_Bytes+1; j++)
		       		     {
        		  		SPI_Write3(RAM_Data_In);
                       		     }
				     SPI_Mode3_Init();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 55 - Read all zeroes and all ones from the RAM. 		      */
/*	case 56 - Read entire data from the RAM.			      */
/*							   		      */
/******************************************************************************/

              		    case 55: /* read all zeroes or all ones from the RAM */
			 	     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
		       		     Error_Flag = 0x00;
				     Start_Add = Word_Add;
				     SPI_Mode3_Init();           	 		
 		       		     SPI_Write3(Start_Add);
        
		       		     for (i=0; i < RAM_Density ; i++)
		       		     {
		    	   		RAM_Data_Out = SPI_Read3();
					if (RAM_Data_Out != RAM_Data_In)
		       	   		{
			      		    Error_Flag = 0x01;
		    	   		}
				     }           
                                     SPI_Mode3_Init();

		       		     if (Error_Flag == 0x01)
	    	          		putchar (Bad_Device);
	               		     else
	    	          		putchar (Good_Device);

        	       		     break;


              		    case 56: /* read entire data from the RAM */
				     SPI_Mode3_Init();           
                                     SPI_Write3(0x00);

		       		     for (i=0; i<RAM_Size; i++)
		       		     {
		    	   		RAM_Data_Out = SPI_Read3();
		    	   		putchar(RAM_Data_Out);
		       		     }
                                     SPI_Mode3_Init();
        	       		     break;

   	      		    default:
		       		     break;
	   		}        /* End of SPI Mode 3 Reg. Selection */
 	           }             /* End of Input Selection */
                   }             /* End of SPI Mode - case 3 */

           default:
		   break;
        }                        /* End of Bus Selection */
}                                /* End of Main Program */


/******************************************************************************/
/*      Subroutine:	Delay	  					      */
/*                                                                            */
/*      Description:    This routine creates a time delay. It will	      */
/*			loop until the 'count' becomes zero. 		      */     															
/*                                                                            */
/*      Input:	        None				   		      */
/*                                                                            */
/*      Return:		None						      */
/*                                                                            */
/******************************************************************************/


void Delay(unsigned int count)
{
	while (count--);
}


void Board_Init()
{
	PCON = 0x00 ; 
	SCON = 0x52 ;
	TMOD = 0x20 ;
	TCON = 0xC0 ;
	TH1 =  0xFD ;

	P1 = 0xFF;
	P4 = 0xFF;
}



/******************************************************************************/
/*									      */
/*	Initialize for SPI Mode 0 (CPOL = 0, CPHA = 0)	 		      */	
/*		    or SPI Mode 3 (CPOL = 1, CPHA = 1)   		      */  
/*									      */	                 
/******************************************************************************/

void SPI_Mode0_Init()                  /* SPI Mode 0 Selection */
{
	   CE =  1;
	   SCL = 1;
	   SCL = 0;
	   CE =  0;
}

void SPI_Mode3_Init()                  /* SPI Mode 3 Selection */
{
	   CE =  1;
	   SCL = 0;
	   SCL = 1;
	   CE =  0;
}				     			

/******************************************************************************/
/*									      */
/*	Subroutine:	SPI_Write 			 		      */	
/*			                                 		      */                   
/******************************************************************************/


void SPI_Write(unsigned char input_byte)
{
	unsigned char i;
	unsigned int mask;

        mask = 0x80; 
	for (i=0; i<8; i++)		/* send one byte of data */

	{
	    SDI = 0;
	    if (mask & input_byte) 	/* send bit according to data */
	    {
	       SDI = 1;
	    }

	    Delay(1);		
	    SCL = 1;			/* clock is high */
	    Delay(1);
	    SCL = 0;                	/* clock is low */
	    mask = mask >> 1;		/* shift right for the next bit */
	}
}


void SPI_Write3(unsigned char input_byte)
{
	unsigned char i;
	unsigned int mask;

        mask = 0x80; 
	SCL = 0;
	for (i=0; i<8; i++)		/* send one byte of data */
	{
	    SDI = 0;
	    if (mask & input_byte) 	/* send bit according to data */
	    {
	       SDI = 1;
	    }

	    Delay(1);		
	    SCL = 1;			/* clock is high */
	    Delay(1);
	    SCL = 0;                	/* clock is low */
	    mask = mask >> 1;		/* shift right for the next bit */
	}
}


/******************************************************************************/
/*									      */	
/*	Subroutine:	SPI_Read 					      */                
/*                                                                    	      */
/******************************************************************************/
	
unsigned char SPI_Read()
{
	unsigned char i;
	unsigned int mask, rec_data;    

	rec_data = 0;	
	mask = 0x80;
	for (i=0; i<8; i++)
	{
	    SCL = 1;
            if (SDA)    
	    {	                
	       rec_data |= mask;
	    }
	    Delay(1);
	    SCL = 0;	
	    mask = mask >> 1;                                                                      
	} 
	return (rec_data);
}

unsigned char SPI_Read3()
{
	unsigned char i;
	unsigned int mask, rec_data;    

	rec_data = 0;	
	mask = 0x80;
	SCL = 0;
	for (i=0; i<8; i++)
	{
	    SCL = 1;
            if (SDA)    
	    {	                
	       rec_data |= mask;
	    }
	    Delay(1);
	    SCL = 0;	
	    mask = mask >> 1;                                                                      
	} 
	return (rec_data);
}
