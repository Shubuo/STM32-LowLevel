/*******************************************************************************/
/*									       */
/*	Title: I2C Code							       */
/*									       */
/*	This example demo code is provided as is and has no warranty, implied  */
/*	or otherwise.  You are free to use/modify any of the provided code at  */
/*	your own risk in your applications.				       */
/*									       */
/*	LIMITATION OF LIABILITY:  NEITHER STMicroelectronics NOR ITS VENDORS   */
/*	OR AGENTS SHALL BE LIABLE FOR ANY LOSS OF PROFITS, LOST OF USE, LOSS   */
/*	OF DATA, INTERRUPTION OF BUSINESS, NOR FOR INDIRECT, SPECIAL,	       */
/*	INCIDENTAL OR CONSEQUENTIAL DAMAGES OF ANY KIND WHETHER UNDER THIS     */
/*	AGREEMENT OR OTHERWISE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH     */
/* 	DAMAGES.							       */
/*									       */
/*   	Application Test Program for: 					       */
/*	-----------------------------					       */	
/*									       */
/* 	      M41T0/T00/T11/T56 (I2C - 8 Bytes RTC Reg. Map)		       */
/* 	      M41T80/T81 (I2C - 20 Bytes RTC Reg. Map)   		       */
/* 	      M41ST84/ST85 (I2C - 20 Bytes RTC Reg. Map) 		       */
/* 	      M41ST87 (I2C - RTC Reg. Map)	       			       */
/*				 					       */
/*=============================================================================*/
/*									       */
/*	Rev.  Description		  Date:	       			       */
/*=============================================================================*/
/*									       */
/*	01 -  Initial Rev.		  03-01-03    			       */			
/*									       */	
/*******************************************************************************/
								
#include <c:\c51\inc\REG515.H> 		/* DEFINE 8051 REGISTERS */
#include <c:\c51\inc\STDIO.H> 		/* DEFINE I/O FUNCTIONS */
#include <c:\c51\inc\CTYPE.H>  		/* DEFINITIONS FOR CHAR CONVERSION */
#include <c:\c51\inc\ABSACC.H> 		/* DIRECT ACCESS TO 8051 MEMORY */
#include <c:\c51\inc\STDLIB.H> 		/* STANDARD LIBRARY */
#include <c:\c51\inc\STRING.H> 		/* STRING FUNCTIONS */
#include <c:\c51\inc\INTRINS.H> 


/********************** PORT ASSIGNMENTS **************************************/
/*									      */
/*  Use Port 1, 4 and 5 for the following signals.			      */
/*									      */
/*  P4.0 = SDA	    (Input/Output)					      */
/*  P4.1 = SCL	   (Input)						      */
/*									      */
/******************************************************************************/



/*********************** FUNCTIONS PROTOTYPE **********************************/
/*									      */
/******************************************************************************/

void main (void);
void Board_Init(void);

/*  I2C Functions Prototype */
void I2CStart(void);                                                                             
void I2C_Init(void);

void Delay(unsigned int count);

unsigned char I2CMasterWrite(unsigned char input_byte);
unsigned char I2CMasterRead(unsigned char ack);
unsigned char I2CStop();


/********************* DEFINE CONSTANTS & GLOBAL VARIABLES ********************/
/*									      */
/*   Define Timekeeper registers constants.				      */
/*									      */
/******************************************************************************/

#define Good_Device 1
#define Bad_Device 2

sbit SDA = P4^0;
sbit SCL = P4^1; 


/******************************************************************************/
/*	Subroutine:	Main			      		      	      */
/*			                                 		      */	
/*	Description:	Write and read to the Timekeeper Register and also    */
/*			write and read to the RAM.			      */
/*                                                                    	      */
/******************************************************************************/

void main(void)
{       /* Start of Main Program */
	unsigned char Dev_Sel;
	unsigned char Sec_Add_Reg, Min_Add_Reg, Hr_Add_Reg, DOW_Add_Reg, DOM_Add_Reg;
	unsigned char Mon_Add_Reg, Yr_Add_Reg, Cont_Add_Reg, Word_Add, RAM_Size;
        unsigned char Tenths_Sec_Add_Reg, Wdog_Add_Reg, Al_Mon_Add_Reg;
	unsigned char Al_DOM_Add_Reg, Al_Hr_Add_Reg, Al_Min_Add_Reg, Al_Sec_Add_Reg;
	unsigned char Flags_Add_Reg, SQW_Add_Reg, Tamper1_Add_Reg, Tamper2_Add_Reg;
	unsigned char Sel_RTC_Reg, RTC_Data;
	unsigned char Sec_Reg, Min_Reg, Hr_Reg, DOW_Reg, DOM_Reg, Mon_Reg, Yr_Reg;
	unsigned char Cont_Reg, Tenths_Sec_Reg, Wdog_Reg, Al_Mon_Reg, Al_DOM_Reg; 
	unsigned char Al_Hr_Reg, Al_Min_Reg, Al_Sec_Reg,  Flags_Reg, SQW_Reg;
	unsigned char Tamper1_Reg, Tamper2_Reg, Interrupts;
	unsigned char Sec_Data, Min_Data, Hr_Data, DOW_Data, DOM_Data, Mon_Data, Yr_Data;
	unsigned char j, i,  Number_Bytes, Error_Flag;
	unsigned char RAM_Data_In, RAM_Add, RAM_Data_Out, Dev_Add, RTC_Reg_Size, RAM_Density;
	


        Board_Init();
        Dev_Add = 0xD0;

                    /* Start of I2C Mode */
    		   I2C_Init();
   		   Dev_Sel = _getkey();                                       
   		   switch (Dev_Sel)                                      
   		        {	 /* Start of Device Selection */	
      	 		case 1 : /* T0/T00/T11/T56 RTC Address Location */
				 /* T0 & T00 device have no memory */
				 /* T11 & T56 have 56 bytes of memory */
				 P5 = 0xFF;
	       	    		 Sec_Add_Reg = _getkey();
		    		 Min_Add_Reg = _getkey();
	            		 Hr_Add_Reg = _getkey();
		    		 DOW_Add_Reg = _getkey();
		    		 DOM_Add_Reg = _getkey();
	 	    		 Mon_Add_Reg = _getkey();
		    		 Yr_Add_Reg = _getkey();
		    		 Cont_Add_Reg = _getkey();
 	            		 Word_Add = _getkey();
		    		 RAM_Size = _getkey();
                    		 break ;

           		case 2 : /* M41T80/T81/ST84/ST85 RTC Address Location */
				 /* T80 & T81 device have no memory */
				 /* ST84 & ST85 have 56 bytes of memory */	
				 P5 = 0xFF;
	       	    		 Tenths_Sec_Add_Reg = _getkey();
	       	    	 	 Sec_Add_Reg = _getkey();
		    		 Min_Add_Reg = _getkey();
	            		 Hr_Add_Reg =  _getkey();
		    		 DOW_Add_Reg = _getkey();
		    		 DOM_Add_Reg = _getkey();
	 	    		 Mon_Add_Reg = _getkey();
		    		 Yr_Add_Reg =  _getkey();
		    		 Cont_Add_Reg = _getkey();
	 	    		 Wdog_Add_Reg = _getkey();
	 	    		 Al_Mon_Add_Reg = _getkey();
		    	         Al_DOM_Add_Reg = _getkey();
		    		 Al_Hr_Add_Reg = _getkey();
		    		 Al_Min_Add_Reg = _getkey();
		    		 Al_Sec_Add_Reg = _getkey();
		    		 Flags_Add_Reg = _getkey();
 		    		 SQW_Add_Reg = _getkey();
 	            		 Word_Add = _getkey();
		    		 RAM_Size = _getkey();
                    		 break ;

           		case 3 : /* M41ST87 RTC Address Location */
				 /* ST87 has 144 bytes of memory */
				 P5 = 0xEF;
	       	    		 Tenths_Sec_Add_Reg = _getkey();
	       	    	 	 Sec_Add_Reg = _getkey();
		    		 Min_Add_Reg = _getkey();
	            		 Hr_Add_Reg =  _getkey();
		    		 DOW_Add_Reg = _getkey();
		    		 DOM_Add_Reg = _getkey();
	 	    		 Mon_Add_Reg = _getkey();
		    		 Yr_Add_Reg =  _getkey();
		    		 Cont_Add_Reg = _getkey();
	 	    		 Wdog_Add_Reg = _getkey();
	 	    		 Al_Mon_Add_Reg = _getkey();
		    	         Al_DOM_Add_Reg = _getkey();
		    		 Al_Hr_Add_Reg = _getkey();
		    		 Al_Min_Add_Reg = _getkey();
		    		 Al_Sec_Add_Reg = _getkey();
		    		 Flags_Add_Reg = _getkey();
 		    		 SQW_Add_Reg = _getkey();
				 Tamper1_Add_Reg = _getkey();
				 Tamper2_Add_Reg = _getkey();
 	            		 Word_Add = _getkey();
		    		 RAM_Size = _getkey();
                    		 break ;

           		default:
 	       			 break ;                         
		        }
                                 /* End of Device Selection */
		   while(1)
		   {             /* Start of Input Selection */
	   		Sel_RTC_Reg = _getkey ();
                                                            
	   		switch (Sel_RTC_Reg)
	   		{	 /* Start of RTC Reg. Selection */
              		    case 11: /* write to seconds register */
		            	     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Sec_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;
                                        	
              		    case 12: /* write to minutes register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       	 	     if (I2CMasterWrite(Min_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 13: /* write to hours register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Hr_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 14: /* write to day register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          	     	I2CStop();    

		       		     if (I2CMasterWrite(DOW_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	         		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 15: /* write to date register */
                       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(DOM_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

             		    case 16: /* write to month register */
		       		     RTC_Data = _getkey();	
		       	 	     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          	     	I2CStop();    

		       		     if (I2CMasterWrite(Mon_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		        I2CStop();
        	      		     break;

              		    case 17: /* write to year register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();		
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Yr_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 18: /* write to control register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		  
  				     if (I2CMasterWrite(Cont_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 19: /* write to watchdog register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Wdog_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;


              		    case 20: /* write to alarm month register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Al_Mon_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;


              		    case 21: /* write to alarm date register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		      		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Al_DOM_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 22: /* write to alarm hour register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Al_Hr_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		      		     I2CStop();
        	       		     break;

              		    case 23: /* write to alarm minute register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Al_Min_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 24: /* write to alarm second register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Al_Sec_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 25: /* write OF bit to the flags register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Flags_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 26: /* read the flags register */
		       		     I2CStart();
 		       		     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(Flags_Add_Reg))
	      	   	 		I2CStop();      
		       		     
				     I2CStart();                 	                                          	
 		       		     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
                                                   
		       		     Flags_Reg = I2CMasterRead(1);
		       		     putchar (Flags_Reg);
		       		     I2CStop();
        	       		     break;


/******************************************************************************/
/*									      */
/*   case 27-29 are not used (reserved registers)			      */
/*									      */
/******************************************************************************/


              		    case 30: /* write to SQW register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(SQW_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 31: /* write to Tamper1 register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

		       		     if (I2CMasterWrite(Tamper1_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;

              		    case 32: /* write to Tamper2 register */
		       		     RTC_Data = _getkey();	
		       		     I2CStart();
		       		     if (I2CMasterWrite(Dev_Add))
	   	          		I2CStop();    

\
		       		     if (I2CMasterWrite(Tamper2_Add_Reg))
	   	          		I2CStop();

        	       		     if (I2CMasterWrite(RTC_Data))
	   	          		I2CStop();

		       		     I2CStop();
        	       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 40 - Reading the RTC Reg. of T0/T00/T11/T56 devices.	      */
/*							   		      */
/******************************************************************************/

              		    case 40: /* Read the RTC Reg. Map */
		       		     I2CStart();           	 	
				     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(Sec_Add_Reg))
	      	   	 		I2CStop();
        
		       		     I2CStart();                     	
                                     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
        
		       		     Sec_Reg = I2CMasterRead(0);
		       		     Min_Reg = I2CMasterRead(0);
		       		     Hr_Reg =  I2CMasterRead(0);
		       		     DOW_Reg = I2CMasterRead(0);
                       		     DOM_Reg = I2CMasterRead(0);
		       		     Mon_Reg = I2CMasterRead(0);
		       		     Yr_Reg =  I2CMasterRead(0);
		       		     Cont_Reg = I2CMasterRead(1);
		       		     Interrupts = P1;
                       		     I2CStop();

 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Interrupts);	
        	       		     break;

/******************************************************************************/
/*							 		      */
/*  	case 41 - Reading the RTC Reg. of T80/T81/ST84/ST85 devices (I2C)     */	
/*							   		      */
/******************************************************************************/

              		    case 41: /* Read the RTC Reg. Map */
				     I2CStart();           	 	
				     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(Tenths_Sec_Add_Reg))
	      	   	 		I2CStop();
        
		       		     I2CStart();                     	
				     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
        
		       		     Tenths_Sec_Reg = I2CMasterRead(0);	
		       		     Sec_Reg = I2CMasterRead(0);
		       		     Min_Reg = I2CMasterRead(0);
		       		     Hr_Reg =  I2CMasterRead(0);
		       		     DOW_Reg = I2CMasterRead(0);
                       		     DOM_Reg = I2CMasterRead(0);
		       		     Mon_Reg = I2CMasterRead(0);
		       		     Yr_Reg =  I2CMasterRead(0);
		       		     Cont_Reg = I2CMasterRead(0);
		        	     Wdog_Reg = I2CMasterRead(0);	
		       		     Al_Mon_Reg = I2CMasterRead(0);
		       		     Al_DOM_Reg = I2CMasterRead(0);
		       		     Al_Hr_Reg = I2CMasterRead(0);
		       		     Al_Min_Reg = I2CMasterRead(0);
		       		     Al_Sec_Reg = I2CMasterRead(1);
                                     I2CStop();

		       		     I2CStart();
 		       		     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(SQW_Add_Reg))
	      	   	 		I2CStop();
        
		       		     I2CStart();                 	                                          	
 		       		     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
                                                   
		       		     SQW_Reg = I2CMasterRead(1);
 		       		     I2CStop();

		       		     Interrupts = P1;

		       	 	     putchar (Tenths_Sec_Reg);
 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Wdog_Reg);
		       		     putchar (Al_Mon_Reg);
		      		     putchar (Al_DOM_Reg);
		       		     putchar (Al_Hr_Reg);
		       		     putchar (Al_Min_Reg);
		       		     putchar (Al_Sec_Reg);
	                             putchar (SQW_Reg);
		       		     putchar (Interrupts);	
        	      		     break;



/******************************************************************************/
/*							 		      */
/*  	case 42 - Reading the RTC Reg. of ST87 device (I2C)		      */	
/*							   		      */
/******************************************************************************/

              		    case 42: /* Read the RTC Reg. Map */
				     I2CStart();           	 	
				     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(Tenths_Sec_Add_Reg))
	      	   	 		I2CStop();
        
		       		     I2CStart();                     	
				     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
        
		       		     Tenths_Sec_Reg = I2CMasterRead(0);	
		       		     Sec_Reg = I2CMasterRead(0);
		       		     Min_Reg = I2CMasterRead(0);
		       		     Hr_Reg =  I2CMasterRead(0);
		       		     DOW_Reg = I2CMasterRead(0);
                       		     DOM_Reg = I2CMasterRead(0);
		       		     Mon_Reg = I2CMasterRead(0);
		       		     Yr_Reg =  I2CMasterRead(0);
		       		     Cont_Reg = I2CMasterRead(0);
		        	     Wdog_Reg = I2CMasterRead(0);	
		       		     Al_Mon_Reg = I2CMasterRead(0);
		       		     Al_DOM_Reg = I2CMasterRead(0);
		       		     Al_Hr_Reg = I2CMasterRead(0);
		       		     Al_Min_Reg = I2CMasterRead(0);
		       		     Al_Sec_Reg = I2CMasterRead(1);
                                     I2CStop();

		       		     I2CStart();
 		       		     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop(); 

		       		     if (I2CMasterWrite(SQW_Add_Reg))
	      	   	 		I2CStop();
        
		       		     I2CStart();                 	                                          	
 		       		     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	 		I2CStop();
                                                   
		       		     SQW_Reg = I2CMasterRead(0);
		       		     Tamper1_Reg = I2CMasterRead(0);
		       		     Tamper2_Reg = I2CMasterRead(1);	
 		       		     I2CStop();

		       		     Interrupts = P1;

		       	 	     putchar (Tenths_Sec_Reg);
 		       		     putchar (Sec_Reg);
		       		     putchar (Min_Reg);
		       		     putchar (Hr_Reg);
		       		     putchar (DOW_Reg);
		       		     putchar (DOM_Reg);
		       		     putchar (Mon_Reg);
		       		     putchar (Yr_Reg);
		       		     putchar (Cont_Reg);
		       		     putchar (Wdog_Reg);
		       		     putchar (Al_Mon_Reg);
		      		     putchar (Al_DOM_Reg);
		       		     putchar (Al_Hr_Reg);
		       		     putchar (Al_Min_Reg);
		       		     putchar (Al_Sec_Reg);
	                             putchar (SQW_Reg);
		       		     putchar (Tamper1_Reg);
		       		     putchar (Tamper2_Reg);
		       		     putchar (Interrupts);	
        	      		     break;


/*******************************************************************************/
/*							 		       */
/*  	case 45 - Write (Burst) Time to the RTC Reg. 			       */	
/*		  					 		       */
/*******************************************************************************/

              		    case 45: 
		       		     Sec_Data = _getkey();
				     Min_Data = _getkey();
		       		     Hr_Data =  _getkey();
				     DOW_Data = _getkey();
		       		     DOM_Data = _getkey();
				     Mon_Data = _getkey();	
		       		     Yr_Data =  _getkey();

		       		     I2CStart();                   		 

		       		     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop();    

		       		     if (I2CMasterWrite(Sec_Add_Reg))
	   	   	 		I2CStop();

				     I2CMasterWrite(Sec_Data);
				     I2CMasterWrite(Min_Data);
				     I2CMasterWrite(Hr_Data);
				     I2CMasterWrite(DOW_Data);
				     I2CMasterWrite(DOM_Data);
				     I2CMasterWrite(Mon_Data);
				     I2CMasterWrite(Yr_Data);
				     I2CStop();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 50 - Write all zeroes & all ones to the RAM. 		      */
/*	case 51 - Write data to certain location of the RAM.		      */
/*							   		      */
/******************************************************************************/

	      		    case 50: /* write all zeroes or ones pattern to the RAM */	
		       		     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
		       		     I2CStart();                   		 

		       		     if (I2CMasterWrite(Dev_Add))
	   	   	 		I2CStop();    

		       		     if (I2CMasterWrite(Word_Add))
	   	   	 		I2CStop();

                       		     for (j=0; j<RAM_Density; j++)
		       		     {
        		  		if (I2CMasterWrite(RAM_Data_In))
	   	   	     		I2CStop();
                       		     }
				     I2CStop();
                       		     break;


	      		    case 51: /* write data to certain location of the RAM */
				     RAM_Add = _getkey();
		       		     Number_Bytes = _getkey();
		       		     RAM_Data_In = _getkey();
		       		     I2CStart();                   		 

		       		     if (I2CMasterWrite(Dev_Add))
	   	   	  		I2CStop();    

		       		     if (I2CMasterWrite(RAM_Add))
	   	   	  		I2CStop();

                       		     for (j=0; j<Number_Bytes+1; j++)
		       		     {
        		  		if (I2CMasterWrite(RAM_Data_In))
	   	   	     		   I2CStop();
                       		     }
				     I2CStop();
                       		     break;



/******************************************************************************/
/*							 		      */
/*  	case 55 - Read all zeroes and all ones from the RAM. 		      */
/*	case 56 - Read entire data from the RAM.			      */
/*							   		      */
/******************************************************************************/

              		    case 55: /* read all zeroes or all ones from the RAM */
			 	     RAM_Data_In = _getkey();
				     RTC_Reg_Size = _getkey();
				     RAM_Density = RAM_Size - RTC_Reg_Size;
		       		     Error_Flag = 0x00;
				     I2CStart();           	 		

 		       		     if (I2CMasterWrite(Dev_Add))
	   	   	  		I2CStop(); 

		       		     if (I2CMasterWrite(Word_Add))
	      	   	  		I2CStop();
        
		       		     I2CStart();                     	
		 		     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	  		I2CStop();
        
		       		     for (i=0; i < RAM_Density-1 ; i++)
		       		     {
		    	   		RAM_Data_Out = I2CMasterRead(0);
					if (RAM_Data_Out != RAM_Data_In)
		       	   		{
			      		    Error_Flag = 0x01;
		    	   		}
				     }
	             
		       		     RAM_Data_Out = I2CMasterRead(1);
		       		     if (RAM_Data_Out != RAM_Data_In) 
		       		     {
		   	  		Error_Flag = 0x01;
		       		     }

		       		     if (Error_Flag == 0x01)
	    	          		putchar (Bad_Device);
	               		     else
	    	          		putchar (Good_Device);

		       		     I2CStop();
        	       		     break;


              		    case 56: /* read entire data from the RAM */
				     I2CStart();           	 		

 		       		     if (I2CMasterWrite(Dev_Add))
	   	   	  		I2CStop(); 

		       		     if (I2CMasterWrite(0))
	      	   	  		I2CStop();
        
		       		     I2CStart();                     	                                        	
 		       		     if (I2CMasterWrite(Dev_Add+1))  	                                   
	   	   	  		I2CStop();
        
		       		     for (i=0; i<RAM_Size-1; i++)
		       		     {
		    	   		RAM_Data_Out = I2CMasterRead(0);
		    	   		putchar(RAM_Data_Out);
		       		     }
	             
		       		     RAM_Data_Out = I2CMasterRead(1);
		       		     putchar(RAM_Data_Out);
		       		     I2CStop();
        	       		     break;

   	      		    default:
		       		     break;
	   		}        /* End of RTC Reg. Selection */
                   }             /* End of I2C Mode */

}                                /* End of Main Program */


/******************************************************************************/
/*      Subroutine:	Delay	  					      */
/*                                                                            */
/*      Description:    This routine creates a time delay. It will	      */
/*			loop until the 'count' becomes zero. 		      */     															
/*                                                                            */
/*      Input:	        None				   		      */
/*                                                                            */
/*      Return:		None						      */
/*                                                                            */
/******************************************************************************/


void Delay(unsigned int count)
{
	while (count--);
}


void Board_Init()
{
	PCON = 0x00 ; 
	SCON = 0x52 ;
	TMOD = 0x20 ;
	TCON = 0xC0 ;
	TH1 =  0xFD ;

	P1 = 0xFF;
	P4 = 0xFF;
}


/******************************************************************************/
/*	Subroutine:	I2C_Init 				    	      */
/*			                             			      */
/*	Description:	Initialize the I2C bus 			              */	
/*                                                                            */
/*      Input:	    	None						      */
/*                       	                                              */
/******************************************************************************/

void I2C_Init()
{
	PCON = 0x00 ; 
	SCON = 0x52 ;
	TMOD = 0x20 ;
	TCON = 0xC0 ;
	TH1 =  0xFD ;

	P1 = 0xFF;
	P4 = 0xEF;
	P5 = 0xFF;
}
		


/******************************************************************************/
/*	Subroutine:	I2CStart     					      */
/*			                              			      */
/*	Description:	Generate a START condition on I2C bus		      */	
/*                                                                            */
/*      Input:	    	None						      */
/*                                                                            */
/*      Return:		None						      */
/*                                                                            */
/******************************************************************************/

void I2CStart()
{
	SDA = 1;        /* to make sure the SDA and SCL are both high */
	SCL = 1;
	Delay(5);       /* add delay */

	SDA = 0;        /* SDA line go LOW first */
	Delay(10);
	SCL = 0;        /* then followed by SCL line with time delay */
}



/******************************************************************************/
/*	Subroutine:	I2CMasterWrite			 		      */
/*			                                 		      */
/*	Description:	Output one byte of data to slave device. Check for    */
/* 			WAIT condition before every bit is sent.	      */ 
/*                                                                            */
/*      Input:	    	one byte of data to be sent to slave device.	      */
/*                                                                            */
/*      Return:		acknowledgement from slave:         		      */
/*		        0 = acknowledge is received			      */
/*	       	 	1 = no acknowledge is received			      */                       
/*                                                                    	      */
/******************************************************************************/

unsigned char I2CMasterWrite(unsigned char input_byte)
{
	unsigned char i;
	unsigned int mask;

        mask = 0x80;                      
	for (i=0; i<8; i++)		/* send one byte of data */
	{
   	   if (mask & input_byte) 	/* send bit according to data */
	      SDA = 1;
	   else SDA = 0;
	
	   mask = mask >> 1;		/* shift right for the next bit */
	   Delay(0);
	   SCL = 1;			/* clock is high */
           Delay (1);
	   SCL = 0;                     /* clock is low */
        }

      	mask = SDA;			/* read acknowledge */
      	Delay(3);
        SCL = 1;			/* generate 9th clock pulse */
	Delay(1);
	SCL = 0;                	/* clock is low */	
	Delay(6);			/* to avoid short pulse transition on SDA line */	
	return (mask);          	/* return acknowledge bit */
}	
						     			


/******************************************************************************/
/*	Subroutine:	I2CMasterRead			 		      */
/*			                                 		      */
/*	Description:	Read one byte of data from the slave device. Check    */
/*			for WAIT condition before every bit is received.      */	
/*                                                                            */
/*      Input:	     	Acknowledge require:				      */
/*			0 - generate LOW output after a byte is received      */
/*			1 - generate HIGH output after a byte is received     */
/*                                                                            */
/*      Return:  	received one byte of data from slave device	      */
/*		        						      */                       
/*                                                                    	      */
/******************************************************************************/
				
unsigned char I2CMasterRead(unsigned char ack)
{
	unsigned char i;
	unsigned int mask, rec_data;    

	rec_data = 0;	
	mask = 0x80;	
	for (i=0; i<8; i++)
	{
            if (SDA)                    
	    	rec_data |= mask;

	    mask = mask >> 1;   
            SCL = 1;       		/* clock is high */
	    Delay(2);      
	    SCL = 0;                    /* clock is low */                                                                       
	} 

	if (ack)               		/* set SDA data first before port direction */	
	   SDA = 1;             	/* send acknowledge */
	else SDA = 0;
       
	Delay(3);
 	SCL = 1;    	  		/* clock is high */
	Delay(1);
	SCL = 0;                	/* clock is low */
	SDA = 1;
	Delay(6);			/* to avoid short pulse transition on SDA line */
	return (rec_data);
}	


/******************************************************************************/
/*	Subroutine:	I2CStop				 		      */
/*			                                 		      */
/*	Description:	generate stop condition on the I2C bus	     	      */	
/*                                                                            */
/*      Input:	     	none                                                  */
/*                                                                            */
/*      Return:  	"0" - the bus line is OK		              */
/*                                                                    	      */
/******************************************************************************/
				
unsigned char I2CStop()
{
       	SDA  = 0;
	SCL =1 ;
   	Delay(10);		
	SDA = 1;
	return (0);
}

