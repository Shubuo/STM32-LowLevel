/******************** (C) ExpKits 2011 STM32 MCU   **************************
*
* Dosya Adi          : lcd.h Header
* Yazar				 : Burak Yörük
* Version            : V1.0.0
* Tarih              : 17/Eylül/2018
*
****************************************************************************/

void veri_yolla(unsigned char byte);
void lcd_clear(void);
void lcd_yaz(const char * s);
void lcd_gotoxy(unsigned char x, unsigned char y);
void lcd_init(void);
void lcd_komut(unsigned char c);

