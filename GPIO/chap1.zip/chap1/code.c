#include"stm32f4xx.h"


 int main(void)
{
	
	RCC->AHB1ENR |= (1<<3); 
  
	GPIOD->MODER |=(1<<15*2)+(1<<14*2);

	GPIOD->OSPEEDR  |=(2<<15*2)+(2<<14*2);
	
	GPIOD->ODR   |=(1<<15)+(1<<14);


}