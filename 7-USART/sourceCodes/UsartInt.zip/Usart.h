/* UART Buffer definitions */
#define BUFFER_SIZE                    20
#define NUMBER_OF_BUFFERS              3

#pragma interrupt_handler UART_RX_interrupt:iv_USART_RXC
#pragma interrupt_handler UART_TX_interrupt:iv_USART_TXC

/* Global Variables */
unsigned char Buffers[NUMBER_OF_BUFFERS][BUFFER_SIZE+1];
volatile unsigned char RxBuffer = 0;
volatile unsigned char TxBuffer;
volatile unsigned char gucFlags = 0;
volatile unsigned char RxCount = 0;
volatile unsigned char *RxPtr;
volatile unsigned char *TxPtr;

#define TEST_MSG_FLAG                  gucFlags&BIT(0)
#define SET_MSG_FLAG                   gucFlags|=BIT(0)
#define CLEAR_MSG_FLAG                 gucFlags&=~BIT(0)




