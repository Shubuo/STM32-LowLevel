/* ************************************************************************ *\
  File:    'UsartInt.c'

  Purpose: Contains example code for the use of the USART interrupts in an
           ATmega32. The M32 receives characters from a terminal and places
           them in a buffer. If either a <CR> is received or the buffer is
           full, the contents of the current receive buffer are transmitted
           under interrupt control and further received characters are placed
           in a new buffer. This process continues forever.

           This example uses four buffers of four characters each. Thus the
           user will have to type four characters before anything appears.

  Author:  John Baraclough
  Date:    2005-10-06
  
  Notes:
\* ************************************************************************ */
#include <iom32v.h>
#include <macros.h>
//#include "usart.h"

#pragma interrupt_handler              UART_RX_interrupt:iv_USART_RXC
#pragma interrupt_handler              UART_TX_interrupt:iv_USART_TXC

#define ENABLE_RX_INT                  UCSRB|=BIT(RXCIE)
#define DISABLE_RX_INT                 UCSRB&=~BIT(RXCIE)
#define ENABLE_TX_INT                  UCSRB|=BIT(TXCIE)
#define DISABLE_TX_INT                 UCSRB&=~BIT(TXCIE)

/* UART Buffer definitions */
#define BUFFER_SIZE                    4
#define NUMBER_OF_BUFFERS              4

/* Global Variables */
unsigned char Buffers[NUMBER_OF_BUFFERS][BUFFER_SIZE+1];
volatile unsigned char RxBuffer = 0;
volatile unsigned char TxBuffer;
volatile unsigned char gucFlags = 0;
volatile unsigned char RxCount = 0;
volatile unsigned char *RxPtr;
volatile unsigned char *TxPtr;

#define TEST_MSG_FLAG                  gucFlags&BIT(0)
#define SET_MSG_FLAG                   gucFlags|=BIT(0)
#define CLEAR_MSG_FLAG                 gucFlags&=~BIT(0)


//ICC-AVR application builder : 06/10/2005 18:25:18
// Target : M32
// Crystal: 14.7456Mhz

void port_init(void)
{
  PORTA = 0x00;
  DDRA  = 0x00;
  PORTB = 0xFF;
  DDRB  = 0xFF;
  PORTC = 0x00; 
  DDRC  = 0x00;
  PORTD = 0x00;
  DDRD  = 0x00;
}

//UART0 initialize
// desired baud rate: 19200
// actual: baud rate:19200 (0.0%)
// char size: 8 bit
// parity: Disabled
void uart0_init(void)
{
  UCSRB = 0x00; //disable while setting baud rate
  UCSRA = 0x00;
  UCSRC = BIT(URSEL) | 0x06;
  UBRRL = 0x2F; //set baud rate lo
  UBRRH = 0x00; //set baud rate hi
  UCSRB = 0xD8;
}

//call this routine to initialize all peripherals
void init_devices(void)
{
  port_init();
  uart0_init();

  MCUCR = 0x00;
  GICR  = 0x00;
  TIMSK = 0x00;
}

/* ************************************************************************ *\
  Function: 'SendMessage()'.

  Action:	1. Set the transmit pointer to the start of the current receive
             buffer and increments the buffer pointer. If the last buffer has
             been used the pointer cycles round to the first buffer.

          2. Send the first character of the message.

          3. If there are more characters to send then enable the transmit
             interrupt.

  Inputs: None
  Ouputs: None
  
  Author:	John Baraclough
  Date:		2005-10-06
  
  Notes:
\* ************************************************************************ */
void SendMessage(void)
{
  _CLI();                                      // Disable interrupts

  TxPtr = Buffers[RxBuffer++];                 // Set the transmit pointer to the start of the most recent receive buffer.
  if(RxBuffer == NUMBER_OF_BUFFERS)            // Do we need to cycle around to the first buffer again?
  {
    RxBuffer = 0;
  }

  RxPtr = Buffers[RxBuffer];                   // Set the receive pointer to the start of the next receive buffer.
  RxCount = 0;                                 // Clear the receive counter.

  UDR = *TxPtr++;                              // There must be at least one charcter in the buffer.
  if(*TxPtr != 0)                              // If the next character isn't NULL then enable the TX interrupt.
  {
    ENABLE_TX_INT;
  }
  _SEI();                                      // Now enable the global interrupt flag.
}


/* ************************************************************************ *\
  Function: 'UART_RX_interrupt()'.

  Action:	1. Places the received character in the buffer.

          2. Check if if the received character is <CR> or if the buffer is full.
             If so then terminate the buffer and set the message flag.

  Inputs: None
  Ouputs: None
  
  Author:	John Baraclough
  Date:		2005-10-06
  
  Notes:
\* ************************************************************************ */
void UART_RX_interrupt(void)
{
  unsigned char Temp;

  Temp = UDR;                                  // Reading the data register clears the interrupt.
  *RxPtr++ = Temp;                             // Save the data in the buffer and ...
  RxCount++;                                   // ... increment the count.

  if((Temp==0x0d)||(RxCount==BUFFER_SIZE))     // Is it a <CR> or is the buffer full?
  {
    *RxPtr = 0;                                // Terminate the message and ...
    SET_MSG_FLAG;                              // ... tell 'main()' that the buffer is ready.
  }
}


/* ************************************************************************ *\
  Function: 'UART_TX_interrupt()'.

  Action:	1. Send the next character and increment the pointer.
  
          2. Check that there are more characters to go and if not disable the
             transmit interrupt as it is not needed until the current receive
             buffer is full.

  Inputs: None
  Ouputs: None
  
  Author:	John Baraclough
  Date:		2005-10-06
  
  Notes:
\* ************************************************************************ */
void UART_TX_interrupt(void)
{
  UDR = *TxPtr++;                              // Writing the data register clears the interrupt.
  if(*TxPtr == 0)                              // Is it the end of the message?
  {
    DISABLE_TX_INT;                            // Yes, so no more to send.
  }
}


/* ************************************************************************ *\
  Function: 'main()'.

  Action:	1. Sets up the device.

          2. Monitor the message flag. If this flag goes true it is cleared
             and the current message sent.

  Inputs: None
  Ouputs: None
  
  Author:	John Baraclough
  Date:		2005-10-06
  
  Notes:
\* ************************************************************************ */
void main( void )
{
 	init_devices();

  RxPtr = Buffers[RxBuffer];                   // Set the receive pointer to the start of the first receive buffer.

	 _SEI();                                      // Enable interrupts.

	 while(1)                                     // Do this forever.
		{
		  if(TEST_MSG_FLAG)
    {
      CLEAR_MSG_FLAG;

      SendMessage();                           // Send the current recieve buffer and switch buffers.
    }  // end of 'if(TEST_MSG_FLAG)'.
		}  // end of 'while(1)'.
}


